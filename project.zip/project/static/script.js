const imageUpload = document.getElementById('imageUpload');
const extractTextButton = document.getElementById('extractTextButton');
const analyzeButton = document.getElementById('analyzeButton');
const ingredientText = document.getElementById('ingredientText');
let extractedText = '';

// Extract text from image using Tesseract.js
extractTextButton.addEventListener('click', () => {
    const file = imageUpload.files[0];
    if (file) {
        extractTextButton.innerText = 'Extracting...';
        Tesseract.recognize(file, 'eng').then(({ data }) => {
            ingredientText.value = data.text;
            extractedText = data.text;
            extractTextButton.innerText = 'Extract Text';
        });
    } else {
        alert('Please upload an image first.');
    }
});

// Analyze ingredients using AI
analyzeButton.addEventListener('click', () => {
    if (!extractedText) {
        alert('Please extract text from an image first.');
        return;
    }

    analyzeButton.innerText = 'Analyzing...';

    fetch('/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ingredients: extractedText })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(`Error: ${data.error}`);
        } else {
            createPieChart(data.percentages);
            fillProsConsTable(data.pros, data.cons);
        }
        analyzeButton.innerText = 'Analyze';
    });
});

// Create pie chart
function createPieChart(percentages) {
    const ctx = document.getElementById('nutritionChart').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Carbohydrates', 'Fats', 'Proteins', 'Vitamins', 'Minerals'],
            datasets: [{
                data: percentages,
                backgroundColor: ['#ff6384', '#36a2eb', '#cc65fe', '#ffce56', '#42f54e']
            }]
        }
    });
}

// Fill pros and cons table
function fillProsConsTable(pros, cons) {
    const tbody = document.querySelector('#pros-cons-table tbody');
    tbody.innerHTML = '';
    for (let i = 0; i < pros.length; i++) {
        const row = `<tr><td>${pros[i]}</td><td>${cons[i]}</td></tr>`;
        tbody.innerHTML += row;
    }
}
