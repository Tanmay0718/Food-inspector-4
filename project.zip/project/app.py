from flask import Flask, request, jsonify, render_template
import openai  # OpenAI is used to call AI
import os

app = Flask(__name__)

# Set your OpenAI API key
openai.api_key = 'YOUR_OPENAI_API_KEY'

@app.route('/')
def home():
    """Render the home page"""
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze_ingredients():
    """Extract and analyze ingredients from text"""
    try:
        data = request.json
        ingredients = data.get('ingredients', '')

        if not ingredients:
            return jsonify({'error': 'No ingredients found'}), 400

        # Prompt to send to the AI
        prompt = f"""
        Analyze the following ingredient list: "{ingredients}". 
        Provide percentages of Carbohydrates, Fats, Proteins, Vitamins, and Minerals. 
        Also, list 5 pros and 5 cons of the food. 
        Return in JSON format like this: 
        {{
            "percentages": [Carbs%, Fats%, Proteins%, Vitamins%, Minerals%], 
            "pros": ["pro1", "pro2", "pro3", "pro4", "pro5"], 
            "cons": ["con1", "con2", "con3", "con4", "con5"]
        }}.
        """

        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=300
        )

        response_text = response.choices[0].text.strip()

        # Convert the AI response to JSON
        response_data = eval(response_text)  # Be careful with eval; ensure the response is trusted
        return jsonify(response_data)
    
    except Exception as e:
        return jsonify({'error': 'Failed to analyze ingredients', 'details': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
